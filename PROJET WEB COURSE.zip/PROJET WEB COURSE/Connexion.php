<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UT<F-8"> <!---->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- -->
    <title>Appliwebcourse</title> <!--Titre du site -->
    <link rel="stylesheet" href="Style-Connexion.css"> <!-- Lien vers le CSS -->
    <link rel="shortcut icon" href="Trophée.png"> <!-- Image pour le titre du site -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet"> <!-- Lien vers Google Fonts -->
</head>

<body>
    <header>
        <div class="Rubrique">
            <a href="Accueil.html">
            <img src="TrophéeT.png" alt="Appliwebcourse" id="logo">
            </a>
            <a class="nav-link" href="Accueil.html">ACCUEIL</a>
            <a class="nav-link" href="Qui_sommes_nous.html">QUI SOMMES NOUS</a>
            <a class="nav-link" href="Evenement.php">ÉVENEMENT</a>
            <a class="nav-link" href="Connexion.php">CONNEXION</a>
            <a class="nav-link" href="Club.php">CLUB</a>
            <a class="nav-link" href="Contact.php">CONTACT</a>
            <a class="nav-link" href="RGPD.php">RGPD</a>
        </div>
    </header>

    <main>
        <div class="Titre">
            <img src="AppliwebcourseT.png" alt="Appliwebcourse" id="logo">
        </div>

        <div class="Titre">
            </div>

        <section class="connexion">
            <h2>Connexion</h2>
            <form method="post" action="traitement_connexion.php"> <label for="pseudo">Pseudo :</label>
                <input type="text" id="pseudo" name="pseudo" required>

                <label for="password">Mot de passe :</label>
                <input type="password" id="password" name="password" required>

                <a href="#">Mot de passe oublié ?</a>

                <button type="submit">Se connecter</button>
            </form>
    </section>

       
    <?php include 'captcha.php'; ?>
</main>


<footer>
<div class="footer-content">
    <div class="Logo">
        <a href="Accueil.html">
            <img src="TrophéeT.png" alt="Page d'accueil">
        </a>
    </div>
    <div class="Mention">
        <a class="nav-link" href="">Mentions légales</a>
        <a class="nav-link" href="">Politique de confidentialité</a>
        <a class="nav-link" href="Chartes_Cookies.html">Chartes cookies</a>
        <a class="nav-link" href="Consentement.html">Consentement</a>
        <a class="nav-link" href="">Nous trouver</a>
    </div>
</div>
<div class="Droits">
    <p>© 2025 APPLIWEBCOURSE. Tous droits réservés.</p>
</div>
</footer>

</body>
</html>