<?php
// Génération de deux nombres aléatoires entre 1 et 10
$num1 = rand(1, 10);
$num2 = rand(1, 10);

// Calcul de la somme
$sum_result = $num1 + $num2;

// Affichage de la question
echo "Veuillez résoudre la somme suivante : " . $num1 . " + " . $num2 . "\n";

// Récupération de la réponse de l'utilisateur
$user_input = intval(readline("Entrez votre réponse : "));

// Vérification de la réponse
if ($user_input == $sum_result) {
    echo "CAPTCHA résolu avec succès. Vous êtes un être humain !\n";
} else {
    echo "Réponse incorrecte. Veuillez réessayer.\n";
}
?>